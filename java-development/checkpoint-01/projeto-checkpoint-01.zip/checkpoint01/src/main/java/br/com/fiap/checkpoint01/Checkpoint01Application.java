package br.com.fiap.checkpoint01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Checkpoint01Application {

	public static void main(String[] args) {
		SpringApplication.run(Checkpoint01Application.class, args);
	}

}
