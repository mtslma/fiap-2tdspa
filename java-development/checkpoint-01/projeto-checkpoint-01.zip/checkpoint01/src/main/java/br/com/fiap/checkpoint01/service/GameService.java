package br.com.fiap.checkpoint01.service;

import br.com.fiap.checkpoint01.dto.GameDTO;
import br.com.fiap.checkpoint01.model.Game;
import br.com.fiap.checkpoint01.repository.GameRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class GameService {

    private final GameRepository gameRepository;

    public GameService(GameRepository gameRepository) {
        this.gameRepository = gameRepository;
    }

    // Função auxiliar para converter DTO para Entity
    private Game toEntity(GameDTO gameDTO) {
        return new Game(
                gameDTO.getId(),
                gameDTO.getName(),
                gameDTO.getDescription(),
                gameDTO.getGenre(),
                gameDTO.getReleaseDate()
        );
    }

    // Função auxiliar para converter Entity para DTO
    private GameDTO toDTO(Game game) {
        return GameDTO.builder()
                .id(game.getId())
                .name(game.getName())
                .description(game.getDescription())
                .genre(game.getGenre())
                .releaseDate(game.getReleaseDate())
                .build();
    }

    // Retornar a lista de jogos completa
    public List<GameDTO> getGames() {
        return gameRepository.findAll().stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    // Retornar um jogo específico por ID
    public Optional<GameDTO> getGameById(UUID id) {
        return gameRepository.findById(id)
                .map(this::toDTO);
    }

    // Adicionar um novo jogo na biblioteca
    public GameDTO addGame(GameDTO gameDTO) {
        Game game = toEntity(gameDTO);
        return toDTO(gameRepository.save(game));
    }

    // Atualizar um jogo existente
    public Optional<GameDTO> updateGame(UUID id, GameDTO gameDTO) {
        return gameRepository.findById(id).map(existingGame -> {
            existingGame.setName(gameDTO.getName());
            existingGame.setDescription(gameDTO.getDescription());
            existingGame.setGenre(gameDTO.getGenre());
            existingGame.setReleaseDate(gameDTO.getReleaseDate());
            return toDTO(gameRepository.save(existingGame));
        });
    }

    // Deletar um jogo
    public boolean deleteGame(UUID id) {
        if (gameRepository.existsById(id)) {
            gameRepository.deleteById(id);
            return true;
        }
        return false;
    }
}