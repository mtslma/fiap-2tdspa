package br.com.fiap.checkpoint01.controller;

import br.com.fiap.checkpoint01.dto.GameDTO;
import br.com.fiap.checkpoint01.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/games")
public class GameController {

    private final GameService gameService;

    public GameController(GameService gameService) {
        this.gameService = gameService;
    }

    // Buscar todos os jogos
    @GetMapping
    public ResponseEntity<List<GameDTO>> getGames() {
        List<GameDTO> games = gameService.getGames();
        return ResponseEntity.ok(games);
    }

    // Buscar um jogo por ID
    @GetMapping("/{id}")
    public ResponseEntity<GameDTO> getGameById(@PathVariable UUID id) {
        return gameService.getGameById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Adicionar um novo jogo
    @PostMapping
    public ResponseEntity<GameDTO> addGame(@RequestBody GameDTO gameDTO) {
        GameDTO newGame = gameService.addGame(gameDTO);
        return new ResponseEntity<>(newGame, HttpStatus.CREATED);
    }

    // Atualizar jogo
    @PutMapping("/{id}")
    public ResponseEntity<GameDTO> updateGame(@PathVariable UUID id, @RequestBody GameDTO gameDTO) {
        return gameService.updateGame(id, gameDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Deletar jogo
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGame(@PathVariable UUID id) {
        boolean deleted = gameService.deleteGame(id);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}