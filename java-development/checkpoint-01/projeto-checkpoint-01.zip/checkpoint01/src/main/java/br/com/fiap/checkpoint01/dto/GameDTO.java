package br.com.fiap.checkpoint01.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Builder
public class GameDTO {

    private UUID id;

    private String name;
    private String description;
    private String genre;

    private LocalDateTime releaseDate;

}
